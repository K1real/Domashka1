package com.example.homework;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    // создание коллекции контейнера для данных класса Animal
    List<Animal> animals = new ArrayList<Animal>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // инициализируем контейнер
        setInitialData();

        // создадим объект RecyclerView и привяжем к нему соответствующий id
        RecyclerView recyclerView = findViewById(R.id.list_animal);

        // создадим адаптер и загрузим в него контейнер с данными
        AnimalAdapter adapter = new AnimalAdapter(this, animals);

        // на recyclerView подадим адаптер
        recyclerView.setAdapter(adapter);
    }

    // метод setInitialData() устанавливает начальный набор данных (а именно изображения из папки res/drawables)
    private void setInitialData() {
        // добавление в контейнер animals объектов сущности Animal
        animals.add( new Animal("Подсолнух", "Полиморфный род растений. Известен цветком, похожим на солнце и наполненным съедобными семянами",
                R.drawable.p1, "Численность большая"));
        animals.add( new Animal("Ромашка", "Одно из самых известных растений в мире. Применяется в медицине",
                R.drawable.p2, "Численность большая"));
        animals.add( new Animal("Дуб", "Род многолетних растений, хорошо узнаваемый по желудям. Деревья этого рода способны жить более 300 лет",
                R.drawable.p3, "Численность большая"));
        animals.add( new Animal("Ламинария", "Род бурых морских водорослей. Ламинария зачастую образует водорослевые леса на небольшой глубине. Пригодна для употребления в пищу и богата витаминами",
                R.drawable.p4, "Численность большая"));
        animals.add( new Animal("Лиственница", "Самое широко распространенное растение в мире, занимающее наибольшую площадь. Это хвойное дерево, на удивление, сбрасывает хвою зимой",
                R.drawable.p5, "Численность большая"));
    }
}